package com.fxall.java.XmlToXmlConversion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmlToXmlConversionApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlToXmlConversionApplication.class, args);
	}

}
